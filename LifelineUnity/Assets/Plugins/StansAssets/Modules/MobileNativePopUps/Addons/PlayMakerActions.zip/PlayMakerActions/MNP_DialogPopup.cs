﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_DialogPopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message; 

		public FsmString yes; 
		public FsmString no;

		public FsmEvent yesEvent;
		public FsmEvent noEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public MNDialogResult ResultInEditor = MNDialogResult.YES;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}


			MobileNativeDialog popup = new MobileNativeDialog(title.Value, message.Value, yes.Value, no.Value);
			popup.OnComplete += OnComplete;

			
		}

		
		public override void Reset() {
			base.Reset();
			
			title =  "Dialog title";
			message   = "Dialog message";
			yes = "Okay";
			no = "No";
			
		}


		private void OnComplete(MNDialogResult result) {
			ParseResult (result);
		}


		private void ParseResult(MNDialogResult res) {
			switch(res) {
			case MNDialogResult.YES:
				Fsm.Event(yesEvent);
				break;
			case MNDialogResult.NO:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}
		
	}
}


