﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_MessagePopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;  




		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Finish();
				return;
			}

			MobileNativeMessage msg = new MobileNativeMessage(title.Value, message.Value);
			msg.OnComplete += OnComplete;
		
		}

		public override void Reset() {
			base.Reset();
			
			title =  "Messahe title";
			message   = "Messahe text";

			
		}



		private void OnComplete() {
			Finish();
		}



		
	}
}


